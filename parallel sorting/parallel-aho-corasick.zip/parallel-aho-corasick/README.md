# parallel-aho-corasick

Open MP Parallelising of Aho Corasick Algorithm using MultiFast Implementation of the same
